# grs-action
🤖 GitHub Action for @anuraghazra/github-readme-stats
